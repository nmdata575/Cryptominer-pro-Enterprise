import React from 'react';

const TestApp = () => {
  return (
    <div style={{ padding: '20px', color: 'white', backgroundColor: '#1a1a2e' }}>
      <h1>🚀 CryptoMiner Pro Test</h1>
      <p>If you can see this, React is working!</p>
    </div>
  );
};

export default TestApp;